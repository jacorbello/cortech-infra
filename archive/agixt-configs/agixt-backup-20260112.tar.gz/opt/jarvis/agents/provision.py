#!/usr/bin/env python3
"""
Provision Jarvis agents in AGiXT.
Creates role-based agents with appropriate permissions and personas.
"""

import os
import sys
import yaml
import httpx
from pathlib import Path

AGIXT_URL = os.getenv("AGIXT_URL", "http://localhost:7437")
AGIXT_API_KEY = os.getenv("AGIXT_API_KEY", "")

HEADERS = {
    "Authorization": f"Bearer {AGIXT_API_KEY}",
    "Content-Type": "application/json",
}


def load_config():
    """Load agents configuration."""
    config_path = Path(__file__).parent / "agents.yaml"
    with open(config_path) as f:
        return yaml.safe_load(f)


def load_system_contract():
    """Load system contract for persona injection."""
    contract_path = Path(__file__).parent.parent / "SYSTEM_CONTRACT.md"
    if contract_path.exists():
        return contract_path.read_text()
    return ""


def get_existing_agents():
    """Get list of existing agents."""
    try:
        resp = httpx.get(f"{AGIXT_URL}/v1/agent", headers=HEADERS, timeout=30)
        if resp.is_success:
            return {a["name"]: a["id"] for a in resp.json().get("agents", [])}
    except Exception as e:
        print(f"Error fetching agents: {e}")
    return {}


def delete_agent(agent_id: str, agent_name: str):
    """Delete an existing agent."""
    try:
        resp = httpx.delete(f"{AGIXT_URL}/v1/agent/{agent_id}", headers=HEADERS, timeout=30)
        if resp.is_success:
            print(f"  Deleted existing agent: {agent_name}")
            return True
        else:
            print(f"  Failed to delete {agent_name}: {resp.text}")
    except Exception as e:
        print(f"  Error deleting {agent_name}: {e}")
    return False


def create_agent(agent_config: dict, system_contract: str):
    """Create an agent in AGiXT."""
    name = agent_config["name"]
    provider = agent_config["provider"]
    model = agent_config["model"]

    # Build persona with system contract
    persona = agent_config.get("persona", "")
    full_persona = f"""# SYSTEM CONTRACT (MANDATORY)

{system_contract}

---

# AGENT-SPECIFIC INSTRUCTIONS

{persona}
"""

    # Map provider to settings
    if provider == "openai":
        settings = {
            "provider": "openai",
            "OPENAI_API_KEY": os.getenv("OPENAI_API_KEY", ""),
            "AI_MODEL": model,
            "MAX_TOKENS": 128000,
            "AI_TEMPERATURE": 0.7,
            "persona": full_persona,
        }
    elif provider == "anthropic":
        settings = {
            "provider": "anthropic",
            "ANTHROPIC_API_KEY": os.getenv("ANTHROPIC_API_KEY", ""),
            "AI_MODEL": model,
            "MAX_TOKENS": 200000,
            "AI_TEMPERATURE": 0.7,
            "persona": full_persona,
        }
    else:
        print(f"  Unknown provider: {provider}")
        return False

    # Build commands (enabled extensions)
    commands = {}
    for ext in agent_config.get("extensions", []):
        commands[ext] = True

    payload = {
        "agent_name": name,
        "settings": settings,
        "commands": commands,
        "training_urls": [],
    }

    try:
        resp = httpx.post(f"{AGIXT_URL}/v1/agent", json=payload, headers=HEADERS, timeout=60)
        if resp.is_success:
            print(f"  Created agent: {name} ({provider}/{model})")
            return True
        else:
            print(f"  Failed to create {name}: {resp.text}")
    except Exception as e:
        print(f"  Error creating {name}: {e}")
    return False


def update_agent_persona(agent_id: str, agent_config: dict, system_contract: str):
    """Update an existing agent's persona."""
    name = agent_config["name"]
    persona = agent_config.get("persona", "")

    full_persona = f"""# SYSTEM CONTRACT (MANDATORY)

{system_contract}

---

# AGENT-SPECIFIC INSTRUCTIONS

{persona}
"""

    try:
        resp = httpx.put(
            f"{AGIXT_URL}/v1/agent/{agent_id}/persona",
            json={"persona": full_persona},
            headers=HEADERS,
            timeout=30,
        )
        if resp.is_success:
            print(f"  Updated persona for: {name}")
            return True
        else:
            print(f"  Failed to update persona for {name}: {resp.text}")
    except Exception as e:
        print(f"  Error updating persona for {name}: {e}")
    return False


def main():
    if not AGIXT_API_KEY:
        print("Error: AGIXT_API_KEY environment variable not set")
        sys.exit(1)

    print("Loading configuration...")
    config = load_config()
    system_contract = load_system_contract()

    if not system_contract:
        print("Warning: System contract not found, proceeding without it")
    else:
        print(f"Loaded system contract ({len(system_contract)} chars)")

    print(f"\nConnecting to AGiXT at {AGIXT_URL}...")
    existing = get_existing_agents()
    print(f"Found {len(existing)} existing agents")

    agents = config.get("agents", [])
    print(f"\nProvisioning {len(agents)} agents...")

    created = 0
    updated = 0
    failed = 0

    for agent in agents:
        name = agent["name"]
        print(f"\n[{name}]")

        if name in existing:
            # Option 1: Delete and recreate
            # if delete_agent(existing[name], name):
            #     if create_agent(agent, system_contract):
            #         created += 1
            #     else:
            #         failed += 1

            # Option 2: Just update persona
            if update_agent_persona(existing[name], agent, system_contract):
                updated += 1
            else:
                failed += 1
        else:
            if create_agent(agent, system_contract):
                created += 1
            else:
                failed += 1

    print(f"\n{'='*50}")
    print(f"Results: {created} created, {updated} updated, {failed} failed")

    # List final state
    print("\nFinal agent list:")
    final_agents = get_existing_agents()
    for name, agent_id in final_agents.items():
        print(f"  - {name} ({agent_id})")


if __name__ == "__main__":
    main()
