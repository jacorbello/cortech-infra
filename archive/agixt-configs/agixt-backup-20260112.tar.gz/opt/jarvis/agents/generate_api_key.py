#!/usr/bin/env python3
"""
Generate a full-access AGiXT API key directly in the database.
"""

import os
import sys
import json
import uuid
import secrets
import hashlib
import psycopg2
from datetime import datetime

# Database connection
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "agixt")
DB_USER = os.getenv("DB_USER", "agixt")
DB_PASS = os.getenv("DB_PASS", "")

# Admin user ID
ADMIN_USER_ID = "779a177d-bdb5-4150-9e04-5cb8219b67af"

# Core scopes (excluding extension-specific ones)
CORE_SCOPES = [
    "agents:read", "agents:write", "agents:delete", "agents:execute", "agents:train",
    "conversations:read", "conversations:write", "conversations:delete", "conversations:share",
    "extensions:read", "extensions:write", "extensions:execute", "extensions:install",
    "memories:read", "memories:write", "memories:delete", "memories:export",
    "chains:read", "chains:write", "chains:delete", "chains:execute", "chains:share",
    "prompts:read", "prompts:write", "prompts:delete", "prompts:share",
    "server:prompts", "server:chains", "server:admin",
    "company:prompts", "company:chains", "company:read", "company:write", "company:delete", "company:billing",
    "companies:manage",
    "users:read", "users:write", "users:delete", "users:roles", "users:impersonate",
    "roles:read", "roles:write", "roles:delete",
    "webhooks:read", "webhooks:write", "webhooks:delete",
    "providers:read", "providers:write", "providers:delete",
    "apikeys:read", "apikeys:write", "apikeys:delete",
    "secrets:read", "secrets:write", "secrets:delete",
    "billing:read", "billing:write", "billing:admin",
    "assets:read", "assets:write", "assets:delete",
    "tickets:read", "tickets:write", "tickets:manage",
    "activity:read", "activity:export",
    "ui:settings", "ui:admin_panel", "ui:voice_only_mode", "ui:full_chat", "ui:developer_mode",
]


def generate_token():
    """Generate a secure random token with agixt_ prefix."""
    return f"agixt_{secrets.token_hex(32)}"  # agixt_ + 64 character hex string


def hash_token(token: str) -> str:
    """Hash token with SHA-256."""
    return hashlib.sha256(token.encode()).hexdigest()


def main():
    # Generate token
    raw_token = generate_token()
    token_prefix = raw_token[:16]  # "agixt_" + first 10 chars of hex
    token_hash = hash_token(raw_token)
    token_id = str(uuid.uuid4())

    # Delete any existing "Jarvis Admin Key" tokens first
    try:
        conn_cleanup = psycopg2.connect(
            host=DB_HOST,
            port=DB_PORT,
            dbname=DB_NAME,
            user=DB_USER,
            password=DB_PASS,
        )
        cur_cleanup = conn_cleanup.cursor()
        cur_cleanup.execute("DELETE FROM personal_access_token WHERE name = 'Jarvis Admin Key'")
        conn_cleanup.commit()
        cur_cleanup.close()
        conn_cleanup.close()
        print("Cleaned up existing Jarvis Admin Key tokens")
    except Exception as e:
        print(f"Cleanup warning: {e}")

    print(f"Generating API key...")
    print(f"Token ID: {token_id}")
    print(f"Token prefix: {token_prefix}...")

    # Connect to database
    try:
        conn = psycopg2.connect(
            host=DB_HOST,
            port=DB_PORT,
            dbname=DB_NAME,
            user=DB_USER,
            password=DB_PASS,
        )
        cur = conn.cursor()

        # Insert the token
        cur.execute("""
            INSERT INTO personal_access_token
            (id, user_id, name, token_prefix, token_hash, scopes_json, agents_json, companies_json, is_revoked, created_at, updated_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, (
            token_id,
            ADMIN_USER_ID,
            "Jarvis Admin Key",
            token_prefix,
            token_hash,
            json.dumps(CORE_SCOPES),
            json.dumps([]),  # All agents
            json.dumps([]),  # All companies
            False,
            datetime.utcnow(),
            datetime.utcnow(),
        ))

        conn.commit()
        cur.close()
        conn.close()

        print(f"\nAPI key created successfully!")
        print(f"\n{'='*60}")
        print(f"NEW AGIXT API KEY:")
        print(f"{'='*60}")
        print(f"{raw_token}")
        print(f"{'='*60}")
        print(f"\nScopes: {len(CORE_SCOPES)} permissions granted")
        print(f"Name: Jarvis Admin Key")

        # Write to file for easy retrieval
        with open("/tmp/agixt_admin_key.txt", "w") as f:
            f.write(raw_token)
        print(f"\nKey also saved to: /tmp/agixt_admin_key.txt")

        return raw_token

    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
