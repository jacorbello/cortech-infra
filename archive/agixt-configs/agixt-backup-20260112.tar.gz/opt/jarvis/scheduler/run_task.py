#!/usr/bin/env python3
"""
Execute a scheduled Jarvis task via AGiXT.
Called by cron with task name as argument.
"""

import os
import sys
import json
import yaml
import httpx
from pathlib import Path
from datetime import datetime

AGIXT_URL = os.getenv("AGIXT_URL", "http://localhost:7437")
AGIXT_API_KEY = os.getenv("AGIXT_API_KEY", "")
TOOLS_GATEWAY_URL = os.getenv("TOOLS_GATEWAY_URL", "http://localhost:8080")
TOOLS_GATEWAY_KEY = os.getenv("TOOLS_GATEWAY_KEY", "")

LOG_DIR = Path("/var/log/jarvis")
LOG_DIR.mkdir(parents=True, exist_ok=True)


def load_tasks():
    """Load task configurations."""
    config_path = Path(__file__).parent / "scheduled_tasks.yaml"
    with open(config_path) as f:
        return yaml.safe_load(f)


def get_agent_id(agent_name: str) -> str:
    """Get agent ID by name."""
    headers = {"Authorization": f"Bearer {AGIXT_API_KEY}"}
    resp = httpx.get(f"{AGIXT_URL}/v1/agent", headers=headers, timeout=30)
    if resp.is_success:
        for agent in resp.json().get("agents", []):
            if agent["name"] == agent_name:
                return agent["id"]
    raise ValueError(f"Agent not found: {agent_name}")


def execute_prompt(agent_id: str, prompt: str, conversation_name: str) -> dict:
    """Execute a prompt with an agent."""
    headers = {
        "Authorization": f"Bearer {AGIXT_API_KEY}",
        "Content-Type": "application/json",
    }

    payload = {
        "model": agent_id,
        "messages": [
            {"role": "user", "content": prompt}
        ],
    }

    resp = httpx.post(
        f"{AGIXT_URL}/v1/chat/completions",
        json=payload,
        headers=headers,
        timeout=300,  # 5 minute timeout for complex tasks
    )

    if resp.is_success:
        return resp.json()
    else:
        raise Exception(f"AGiXT error: {resp.status_code} - {resp.text}")


def notify_webhook(task_name: str, result: str, status: str):
    """Send notification via Tools Gateway webhook."""
    if not TOOLS_GATEWAY_KEY:
        return

    headers = {
        "X-API-Key": TOOLS_GATEWAY_KEY,
        "Content-Type": "application/json",
    }

    payload = {
        "webhook_name": "scheduled-task-complete",
        "data": {
            "task": task_name,
            "status": status,
            "timestamp": datetime.utcnow().isoformat(),
            "summary": result[:500] if result else "No output",
        }
    }

    try:
        resp = httpx.post(
            f"{TOOLS_GATEWAY_URL}/actions/webhook",
            json=payload,
            headers=headers,
            timeout=30,
        )
        if not resp.is_success:
            print(f"Webhook notification failed: {resp.text}")
    except Exception as e:
        print(f"Webhook notification error: {e}")


def run_task(task_name: str):
    """Run a specific scheduled task."""
    config = load_tasks()
    task = None

    for t in config.get("tasks", []):
        if t["name"] == task_name:
            task = t
            break

    if not task:
        print(f"Task not found: {task_name}")
        sys.exit(1)

    if not task.get("enabled", True):
        print(f"Task disabled: {task_name}")
        sys.exit(0)

    print(f"Running scheduled task: {task_name}")
    print(f"Agent: {task['agent']}")
    print(f"Time: {datetime.now().isoformat()}")
    print("-" * 50)

    try:
        # Get agent ID
        agent_id = get_agent_id(task["agent"])
        print(f"Agent ID: {agent_id}")

        # Generate conversation name for this run
        conv_name = f"scheduled-{task_name}-{datetime.now().strftime('%Y%m%d-%H%M%S')}"

        # Execute the prompt
        result = execute_prompt(agent_id, task["prompt"], conv_name)

        # Extract response
        response_text = ""
        if result.get("choices"):
            response_text = result["choices"][0].get("message", {}).get("content", "")

        print("\nResult:")
        print(response_text)

        # Log result
        log_file = LOG_DIR / f"{task_name}.log"
        with open(log_file, "a") as f:
            f.write(f"\n{'='*60}\n")
            f.write(f"Timestamp: {datetime.now().isoformat()}\n")
            f.write(f"Status: SUCCESS\n")
            f.write(f"Response:\n{response_text}\n")

        # Check for drift/issues and notify
        notifications = config.get("notifications", {})
        notify_conditions = notifications.get("notify_on", [])

        should_notify = False
        status = "ok"

        # Check response for trigger conditions
        response_lower = response_text.lower()
        if "drift detected" in response_lower and "drift_detected" in notify_conditions:
            should_notify = True
            status = "drift_detected"
        elif "reindex needed" in response_lower and "reindex_needed" in notify_conditions:
            should_notify = True
            status = "reindex_needed"
        elif "warn" in response_lower and "backup_warning" in notify_conditions:
            should_notify = True
            status = "backup_warning"

        if should_notify:
            notify_webhook(task_name, response_text, status)

        print(f"\nTask completed successfully")

    except Exception as e:
        error_msg = str(e)
        print(f"\nError: {error_msg}")

        # Log error
        log_file = LOG_DIR / f"{task_name}.log"
        with open(log_file, "a") as f:
            f.write(f"\n{'='*60}\n")
            f.write(f"Timestamp: {datetime.now().isoformat()}\n")
            f.write(f"Status: ERROR\n")
            f.write(f"Error: {error_msg}\n")

        # Notify on error
        if "error" in config.get("notifications", {}).get("notify_on", []):
            notify_webhook(task_name, error_msg, "error")

        sys.exit(1)


def list_tasks():
    """List all configured tasks."""
    config = load_tasks()
    print("Configured scheduled tasks:")
    print("-" * 60)
    for task in config.get("tasks", []):
        status = "enabled" if task.get("enabled", True) else "disabled"
        print(f"  {task['name']:20} | {task['schedule']:15} | {status}")
        print(f"    Agent: {task['agent']}")
        print(f"    {task['description']}")
        print()


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: run_task.py <task_name|--list>")
        sys.exit(1)

    if sys.argv[1] == "--list":
        list_tasks()
    else:
        run_task(sys.argv[1])
