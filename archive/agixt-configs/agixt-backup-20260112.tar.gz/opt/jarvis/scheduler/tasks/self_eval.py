#!/usr/bin/env python3
"""
Self-Evaluation Task

Analyzes sanitized telemetry and creates improvement proposals.
Runs daily after telemetry extraction.

Usage:
    python3 -m scheduler.tasks.self_eval [--date YYYY-MM-DD] [--dry-run]
"""

import argparse
import json
import os
import re
import subprocess
import sys
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional


# Paths (relative to jarvis directory)
JARVIS_DIR = Path(__file__).parent.parent.parent
TELEMETRY_DIR = JARVIS_DIR / "telemetry" / "events"
PROPOSALS_DIR = JARVIS_DIR / "proposals"
TEMPLATES_DIR = PROPOSALS_DIR / "templates"
REPORTS_DIR = JARVIS_DIR / "reports" / "errors"


def load_telemetry(date: str) -> list[dict]:
    """Load telemetry events for a given date."""
    telemetry_file = TELEMETRY_DIR / f"{date}.jsonl"
    events = []

    if not telemetry_file.exists():
        print(f"No telemetry file for {date}")
        return events

    with open(telemetry_file, 'r') as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    events.append(json.loads(line))
                except json.JSONDecodeError:
                    continue

    return events


def load_error_reports() -> list[dict]:
    """Load recent error reports."""
    reports = []

    if not REPORTS_DIR.exists():
        return reports

    # Load reports from last 7 days
    cutoff = datetime.utcnow() - timedelta(days=7)

    for report_file in REPORTS_DIR.glob("*.json"):
        try:
            mtime = datetime.fromtimestamp(report_file.stat().st_mtime)
            if mtime < cutoff:
                continue

            with open(report_file, 'r') as f:
                report = json.load(f)
                reports.append(report)
        except (json.JSONDecodeError, IOError):
            continue

    return reports


def analyze_telemetry(events: list[dict]) -> dict:
    """Analyze telemetry events for patterns."""
    analysis = {
        "total_events": len(events),
        "tool_calls": {"total": 0, "failed": 0, "by_tool": {}, "by_agent": {}},
        "task_failures": {"total": 0, "by_task": {}, "by_category": {}},
        "errors": [],
    }

    for event in events:
        event_type = event.get("event_type", "")

        if event_type == "tool_call":
            analysis["tool_calls"]["total"] += 1
            tool = event.get("tool", "unknown")
            agent = event.get("agent", "unknown")
            success = event.get("success", True)

            # Track by tool
            if tool not in analysis["tool_calls"]["by_tool"]:
                analysis["tool_calls"]["by_tool"][tool] = {"total": 0, "failed": 0}
            analysis["tool_calls"]["by_tool"][tool]["total"] += 1

            # Track by agent
            if agent not in analysis["tool_calls"]["by_agent"]:
                analysis["tool_calls"]["by_agent"][agent] = {"total": 0, "failed": 0}
            analysis["tool_calls"]["by_agent"][agent]["total"] += 1

            if not success:
                analysis["tool_calls"]["failed"] += 1
                analysis["tool_calls"]["by_tool"][tool]["failed"] += 1
                analysis["tool_calls"]["by_agent"][agent]["failed"] += 1
                analysis["errors"].append({
                    "type": "tool_call_failure",
                    "tool": tool,
                    "agent": agent,
                    "error_code": event.get("error_code"),
                    "error_message": event.get("error_message"),
                    "timestamp": event.get("timestamp"),
                })

        elif event_type == "task_failure":
            analysis["task_failures"]["total"] += 1
            task = event.get("task_name", "unknown")
            category = event.get("error_category", "unknown")

            if task not in analysis["task_failures"]["by_task"]:
                analysis["task_failures"]["by_task"][task] = 0
            analysis["task_failures"]["by_task"][task] += 1

            if category not in analysis["task_failures"]["by_category"]:
                analysis["task_failures"]["by_category"][category] = 0
            analysis["task_failures"]["by_category"][category] += 1

    return analysis


def format_analysis_for_prompt(analysis: dict, events: list[dict]) -> str:
    """Format analysis into a prompt-friendly string."""
    lines = [
        "## Telemetry Summary",
        f"Total events: {analysis['total_events']}",
        "",
        "### Tool Calls",
        f"Total: {analysis['tool_calls']['total']}",
        f"Failed: {analysis['tool_calls']['failed']}",
        "",
    ]

    if analysis["tool_calls"]["by_tool"]:
        lines.append("By Tool:")
        for tool, stats in sorted(
            analysis["tool_calls"]["by_tool"].items(),
            key=lambda x: x[1]["failed"],
            reverse=True
        )[:10]:
            if stats["failed"] > 0:
                lines.append(f"  - {tool}: {stats['failed']}/{stats['total']} failed")

    if analysis["tool_calls"]["by_agent"]:
        lines.append("\nBy Agent:")
        for agent, stats in sorted(
            analysis["tool_calls"]["by_agent"].items(),
            key=lambda x: x[1]["failed"],
            reverse=True
        )[:10]:
            if stats["failed"] > 0:
                lines.append(f"  - {agent}: {stats['failed']}/{stats['total']} failed")

    if analysis["task_failures"]["total"] > 0:
        lines.extend([
            "",
            "### Task Failures",
            f"Total: {analysis['task_failures']['total']}",
        ])
        for task, count in sorted(
            analysis["task_failures"]["by_task"].items(),
            key=lambda x: x[1],
            reverse=True
        ):
            lines.append(f"  - {task}: {count}")

    if analysis["errors"]:
        lines.extend([
            "",
            "### Recent Errors (sample)",
        ])
        # Show up to 10 unique error patterns
        seen_patterns = set()
        for error in analysis["errors"][:20]:
            pattern = f"{error.get('tool', 'unknown')}:{error.get('error_code', 'unknown')}"
            if pattern not in seen_patterns:
                seen_patterns.add(pattern)
                lines.append(f"  - {pattern}: {error.get('error_message', 'no message')[:100]}")
            if len(seen_patterns) >= 10:
                break

    # Include raw JSONL sample for context (first 50 events)
    lines.extend([
        "",
        "### Raw Telemetry Sample (first 50 events)",
        "```jsonl",
    ])
    for event in events[:50]:
        lines.append(json.dumps(event, separators=(',', ':')))
    lines.append("```")

    return "\n".join(lines)


def parse_proposals_from_response(response: str) -> list[dict]:
    """Parse proposal blocks from EvalAgent response."""
    proposals = []
    pattern = re.compile(r'<proposal>(.*?)</proposal>', re.DOTALL)

    for match in pattern.finditer(response):
        content = match.group(1).strip()

        # Parse proposal fields
        proposal = {
            "raw_content": content,
            "category": "bugfix",
            "severity": "medium",
            "title": "Untitled Proposal",
        }

        # Extract fields
        for line in content.split('\n'):
            line = line.strip()
            if line.startswith('- Category:'):
                proposal["category"] = line.split(':', 1)[1].strip().lower()
            elif line.startswith('- Severity:'):
                proposal["severity"] = line.split(':', 1)[1].strip().lower()
            elif line.startswith('- Title:'):
                proposal["title"] = line.split(':', 1)[1].strip()
            elif line.startswith('- Problem:'):
                proposal["problem"] = line.split(':', 1)[1].strip()
            elif line.startswith('- Evidence:'):
                proposal["evidence"] = line.split(':', 1)[1].strip()
            elif line.startswith('- Solution:'):
                proposal["solution"] = line.split(':', 1)[1].strip()
            elif line.startswith('- Risk:'):
                proposal["risk"] = line.split(':', 1)[1].strip()
            elif line.startswith('- Rollback:'):
                proposal["rollback"] = line.split(':', 1)[1].strip()
            elif line.startswith('- Root Cause:'):
                proposal["root_cause"] = line.split(':', 1)[1].strip()

        # Look for diff block
        diff_match = re.search(r'```diff\n(.*?)```', content, re.DOTALL)
        if diff_match:
            proposal["diff"] = diff_match.group(1).strip()

        proposals.append(proposal)

    return proposals


def create_proposal_file(proposal: dict, dry_run: bool = False) -> Optional[str]:
    """Create proposal markdown file."""
    proposal_id = str(uuid.uuid4())[:8]
    timestamp = datetime.utcnow().isoformat() + "Z"
    date = datetime.utcnow()

    # Create slug from title
    slug = re.sub(r'[^a-z0-9]+', '-', proposal.get("title", "untitled").lower())[:50]

    # Determine output path
    year = date.strftime("%Y")
    month = date.strftime("%m")
    output_dir = PROPOSALS_DIR / year / month
    output_file = output_dir / f"{proposal_id}-{slug}.md"

    # Load template
    template_name = proposal.get("category", "bugfix") + ".md"
    template_path = TEMPLATES_DIR / template_name
    if not template_path.exists():
        template_path = TEMPLATES_DIR / "bugfix.md"

    template = template_path.read_text()

    # Fill template
    content = template.replace("[TITLE]", proposal.get("title", "Untitled"))
    content = content.replace("[UUID]", proposal_id)
    content = content.replace("[TIMESTAMP]", timestamp)
    content = content.replace("[critical|high|medium|low]", proposal.get("severity", "medium"))

    # Replace problem statement
    if "problem" in proposal:
        content = content.replace(
            "[Describe what is broken or malfunctioning]",
            proposal["problem"]
        )

    # Replace evidence section
    if "evidence" in proposal:
        content = re.sub(
            r'## Evidence\n\n.*?(?=\n## )',
            f"## Evidence\n\n{proposal['evidence']}\n\n",
            content,
            flags=re.DOTALL
        )

    # Replace root cause
    if "root_cause" in proposal:
        content = content.replace(
            "[Why this is happening - be specific about the underlying cause]",
            proposal["root_cause"]
        )

    # Replace solution
    if "solution" in proposal:
        content = content.replace(
            "[What to change and why this will fix the issue]",
            proposal["solution"]
        )

    # Replace diff
    if "diff" in proposal:
        content = re.sub(
            r'```diff\n.*?```',
            f"```diff\n{proposal['diff']}\n```",
            content,
            flags=re.DOTALL
        )

    # Replace risk
    if "risk" in proposal:
        content = content.replace(
            "[what could go wrong with this change]",
            proposal["risk"]
        )

    if dry_run:
        print(f"\n=== Would create: {output_file} ===")
        print(content[:500] + "..." if len(content) > 500 else content)
        return None

    # Create directory and write file
    output_dir.mkdir(parents=True, exist_ok=True)
    output_file.write_text(content)

    return str(output_file)


def call_eval_agent(prompt: str, dry_run: bool = False) -> Optional[str]:
    """
    Call EvalAgent via AGiXT API.

    Note: This is a placeholder. In production, this would call the AGiXT API
    with the EvalAgent. For now, we return None to indicate the agent isn't
    available yet.
    """
    agixt_uri = os.environ.get("AGIXT_URI", "http://localhost:7437")
    agixt_key = os.environ.get("AGIXT_API_KEY", "")

    if not agixt_key:
        print("WARNING: AGIXT_API_KEY not set, cannot call EvalAgent")
        return None

    if dry_run:
        print("\n=== Would send to EvalAgent ===")
        print(prompt[:1000] + "..." if len(prompt) > 1000 else prompt)
        return None

    # TODO: Implement actual AGiXT API call
    # For now, return None to indicate no response
    print("NOTE: AGiXT integration not yet implemented")
    return None


def main():
    parser = argparse.ArgumentParser(description="Run self-evaluation task")
    parser.add_argument(
        "--date",
        default=datetime.utcnow().strftime("%Y-%m-%d"),
        help="Date to analyze (YYYY-MM-DD)",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Don't create files or call APIs",
    )
    parser.add_argument(
        "--analyze-only",
        action="store_true",
        help="Only show analysis, don't create proposals",
    )
    args = parser.parse_args()

    print(f"=== Self-Evaluation Task ===")
    print(f"Date: {args.date}")
    print(f"Dry run: {args.dry_run}")

    # Load telemetry
    events = load_telemetry(args.date)
    print(f"Loaded {len(events)} telemetry events")

    if not events:
        print("No telemetry to analyze, exiting")
        return 0

    # Analyze telemetry
    analysis = analyze_telemetry(events)
    print(f"\nAnalysis:")
    print(f"  Tool calls: {analysis['tool_calls']['total']} total, {analysis['tool_calls']['failed']} failed")
    print(f"  Task failures: {analysis['task_failures']['total']}")
    print(f"  Errors: {len(analysis['errors'])}")

    if args.analyze_only:
        print("\n" + format_analysis_for_prompt(analysis, events))
        return 0

    # Check if there are issues worth analyzing
    if analysis['tool_calls']['failed'] == 0 and analysis['task_failures']['total'] == 0:
        print("\nNo failures detected, nothing to propose")
        return 0

    # Load error reports
    error_reports = load_error_reports()
    print(f"Loaded {len(error_reports)} error reports")

    # Format prompt for EvalAgent
    prompt = format_analysis_for_prompt(analysis, events)

    if error_reports:
        prompt += "\n\n## Error Reports\n"
        for report in error_reports[:5]:
            prompt += f"\n{json.dumps(report, indent=2)}"

    # Call EvalAgent
    response = call_eval_agent(prompt, dry_run=args.dry_run)

    if not response:
        print("\nNo response from EvalAgent (or dry run)")
        return 0

    # Parse proposals from response
    proposals = parse_proposals_from_response(response)
    print(f"\nParsed {len(proposals)} proposals from response")

    # Create proposal files
    created = []
    for proposal in proposals:
        filepath = create_proposal_file(proposal, dry_run=args.dry_run)
        if filepath:
            created.append(filepath)
            print(f"Created: {filepath}")

    print(f"\n=== Complete ===")
    print(f"Created {len(created)} proposals")

    return 0


if __name__ == "__main__":
    sys.exit(main())
