#!/usr/bin/env python3
"""
Proposal Notification Task

Sends notifications for pending proposals based on severity.
Implements batching to prevent alert fatigue.

Usage:
    python3 -m scheduler.tasks.notify_proposals [--severity LEVEL] [--digest]
"""

import argparse
import json
import os
import re
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

try:
    import httpx
except ImportError:
    httpx = None


JARVIS_DIR = Path(__file__).parent.parent.parent
PROPOSALS_DIR = JARVIS_DIR / "proposals"
STATE_FILE = JARVIS_DIR / ".notification_state.json"


def load_notification_state() -> dict:
    """Load notification state tracking."""
    if STATE_FILE.exists():
        try:
            return json.loads(STATE_FILE.read_text())
        except json.JSONDecodeError:
            pass
    return {"notified": {}, "last_digest": None}


def save_notification_state(state: dict) -> None:
    """Save notification state."""
    STATE_FILE.write_text(json.dumps(state, indent=2))


def parse_proposal_metadata(filepath: Path) -> dict:
    """Extract metadata from a proposal file."""
    content = filepath.read_text()
    metadata = {
        "filepath": str(filepath),
        "id": filepath.stem.split('-')[0],
        "title": "Untitled",
        "status": "pending",
        "severity": "medium",
    }

    patterns = {
        "id": r'\*\*ID\*\*:\s*(\S+)',
        "status": r'\*\*Status\*\*:\s*(\S+)',
        "severity": r'\*\*Severity\*\*:\s*(\S+)',
    }

    for key, pattern in patterns.items():
        match = re.search(pattern, content)
        if match:
            metadata[key] = match.group(1).strip()

    title_match = re.search(r'^# Proposal:\s*(.+)$', content, re.MULTILINE)
    if title_match:
        metadata["title"] = title_match.group(1).strip()

    return metadata


def find_pending_proposals() -> list[dict]:
    """Find all proposals with status=pending."""
    proposals = []

    for year_dir in PROPOSALS_DIR.iterdir():
        if not year_dir.is_dir() or not re.match(r'^\d{4}$', year_dir.name):
            continue

        for month_dir in year_dir.iterdir():
            if not month_dir.is_dir() or not re.match(r'^\d{2}$', month_dir.name):
                continue

            for proposal_file in month_dir.glob("*.md"):
                if proposal_file.name.startswith('.'):
                    continue

                try:
                    metadata = parse_proposal_metadata(proposal_file)
                    if metadata["status"] == "pending":
                        proposals.append(metadata)
                except Exception:
                    continue

    return proposals


def filter_by_severity(proposals: list[dict], severity: str) -> list[dict]:
    """Filter proposals by minimum severity."""
    severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    min_level = severity_order.get(severity, 2)

    return [
        p for p in proposals
        if severity_order.get(p["severity"], 2) <= min_level
    ]


def filter_unnotified(proposals: list[dict], state: dict, max_age_hours: int = 24) -> list[dict]:
    """Filter out proposals that were recently notified."""
    cutoff = datetime.utcnow() - timedelta(hours=max_age_hours)
    unnotified = []

    for p in proposals:
        notified_at = state["notified"].get(p["id"])
        if notified_at:
            try:
                notified_dt = datetime.fromisoformat(notified_at)
                if notified_dt > cutoff:
                    continue  # Skip recently notified
            except ValueError:
                pass
        unnotified.append(p)

    return unnotified


def format_notification(proposals: list[dict], digest: bool = False) -> str:
    """Format notification message."""
    lines = ["[Jarvis Self-Improvement] Proposals Pending Review", ""]

    if digest:
        lines[0] = "[Jarvis Self-Improvement] Daily Proposal Digest"

    # Group by severity
    by_severity = {"critical": [], "high": [], "medium": [], "low": []}
    for p in proposals:
        sev = p.get("severity", "medium")
        if sev in by_severity:
            by_severity[sev].append(p)

    if by_severity["critical"]:
        lines.append("**CRITICAL (immediate action required):**")
        for p in by_severity["critical"]:
            lines.append(f"  - [{p['id']}] {p['title']}")
        lines.append("")

    if by_severity["high"]:
        lines.append("**High Priority:**")
        for p in by_severity["high"]:
            lines.append(f"  - [{p['id']}] {p['title']}")
        lines.append("")

    if by_severity["medium"]:
        lines.append("**Medium:**")
        for p in by_severity["medium"]:
            lines.append(f"  - [{p['id']}] {p['title']}")
        lines.append("")

    if by_severity["low"]:
        lines.append("**Low:**")
        for p in by_severity["low"]:
            lines.append(f"  - [{p['id']}] {p['title']}")
        lines.append("")

    lines.extend([
        "---",
        "Commands:",
        "  `proposals list` - Show all pending",
        "  `proposals show <id>` - View details",
        "  `proposals approve <id>` - Approve",
        "  `proposals reject <id> <reason>` - Reject",
    ])

    return "\n".join(lines)


def send_notification(message: str, dry_run: bool = False) -> bool:
    """Send notification via webhook."""
    webhook_url = os.environ.get(
        "NOTIFICATION_WEBHOOK_URL",
        "http://tools-gateway:8080/actions/webhook"
    )
    webhook_name = os.environ.get("NOTIFICATION_WEBHOOK_NAME", "proposal-notification")

    if dry_run:
        print("\n=== Would send notification ===")
        print(f"Webhook: {webhook_url}")
        print(f"Message:\n{message}")
        return True

    if not httpx:
        print("WARNING: httpx not installed, cannot send notification")
        print(f"Message:\n{message}")
        return False

    try:
        response = httpx.post(
            webhook_url,
            json={
                "name": webhook_name,
                "message": message,
            },
            timeout=30,
        )
        return response.status_code < 400
    except Exception as e:
        print(f"Failed to send notification: {e}")
        return False


def main():
    parser = argparse.ArgumentParser(description="Send proposal notifications")
    parser.add_argument(
        "--severity",
        choices=["critical", "high", "medium", "low"],
        default="medium",
        help="Minimum severity to notify about",
    )
    parser.add_argument(
        "--digest",
        action="store_true",
        help="Send daily digest instead of individual notifications",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Don't actually send notifications",
    )
    args = parser.parse_args()

    print(f"=== Proposal Notification Task ===")
    print(f"Severity filter: {args.severity}")
    print(f"Digest mode: {args.digest}")

    # Load state
    state = load_notification_state()

    # Find pending proposals
    proposals = find_pending_proposals()
    print(f"Found {len(proposals)} pending proposals")

    if not proposals:
        print("No pending proposals")
        return 0

    # Filter by severity
    proposals = filter_by_severity(proposals, args.severity)
    print(f"After severity filter: {len(proposals)}")

    if not proposals:
        print("No proposals match severity filter")
        return 0

    # Filter unnotified (unless digest mode)
    if not args.digest:
        # For non-digest: filter by severity-specific cooldown
        cooldowns = {"critical": 0, "high": 1, "medium": 24, "low": 24}
        cooldown = cooldowns.get(args.severity, 24)
        proposals = filter_unnotified(proposals, state, max_age_hours=cooldown)
        print(f"After notification filter: {len(proposals)}")

    if not proposals:
        print("All proposals already notified")
        return 0

    # Format and send
    message = format_notification(proposals, digest=args.digest)
    success = send_notification(message, dry_run=args.dry_run)

    if success and not args.dry_run:
        # Update state
        now = datetime.utcnow().isoformat()
        for p in proposals:
            state["notified"][p["id"]] = now
        if args.digest:
            state["last_digest"] = now
        save_notification_state(state)
        print(f"Notification sent, state updated")

    return 0 if success else 1


if __name__ == "__main__":
    sys.exit(main())
