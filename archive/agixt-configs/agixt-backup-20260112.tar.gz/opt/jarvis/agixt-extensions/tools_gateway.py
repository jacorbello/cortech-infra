"""
Tools Gateway Extension for AGiXT
Provides access to Jarvis Tools Gateway actions including iOS notifications.
"""

import os
import json
import logging
import httpx
from typing import Optional, Dict, Any
from Extensions import Extensions

logger = logging.getLogger(__name__)

# Configuration from environment
TOOLS_GATEWAY_URL = os.getenv("TOOLS_GATEWAY_URL", "http://tools-gateway:8080")
TOOLS_API_KEY = os.getenv("TOOLS_API_KEY", "")


class tools_gateway(Extensions):
    """
    Tools Gateway extension for Jarvis.

    Provides access to:
    - iOS push notifications via Home Assistant
    - Approval gates for sensitive actions
    - File reading (allowlisted paths)
    - RAG document search
    - Webhook calls (allowlisted URLs)
    """

    CATEGORY = "Jarvis"
    friendly_name = "Tools Gateway"

    def __init__(
        self,
        TOOLS_GATEWAY_URL: str = "",
        TOOLS_API_KEY: str = "",
        **kwargs
    ):
        self.TOOLS_GATEWAY_URL = TOOLS_GATEWAY_URL or os.getenv("TOOLS_GATEWAY_URL", "http://tools-gateway:8080")
        self.TOOLS_API_KEY = TOOLS_API_KEY or os.getenv("TOOLS_API_KEY", "")

        self.commands = {
            "Send iOS Notification": self.notify_attention,
            "Request Approval": self.request_approval,
            "Check Approval Status": self.check_approval,
            "List Pending Approvals": self.list_pending_approvals,
            "Check Reliability Status": self.check_reliability_status,
            "Read Allowlisted File": self.read_file,
            "Search Documents": self.search_docs,
        }

    async def _request(
        self,
        method: str,
        endpoint: str,
        json_data: Optional[Dict] = None,
    ) -> Dict[str, Any]:
        """Make authenticated request to Tools Gateway."""
        url = f"{self.TOOLS_GATEWAY_URL}{endpoint}"
        headers = {
            "X-API-Key": self.TOOLS_API_KEY,
            "Content-Type": "application/json",
        }

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                if method == "GET":
                    resp = await client.get(url, headers=headers)
                else:
                    resp = await client.post(url, headers=headers, json=json_data or {})

                if resp.is_success:
                    return resp.json()
                else:
                    return {
                        "success": False,
                        "error": f"HTTP {resp.status_code}: {resp.text[:500]}"
                    }
        except Exception as e:
            logger.error(f"Tools Gateway request failed: {e}")
            return {"success": False, "error": str(e)}

    async def notify_attention(
        self,
        severity: str,
        title: str,
        message: str,
        details_url: str = "https://chat.corbello.io",
        dedupe_key: Optional[str] = None,
    ) -> str:
        """
        Send a push notification to the user's iPhone via Home Assistant.

        Args:
            severity: One of 'fyi', 'needs_response', 'urgent', 'approval'
                - fyi: Informational (suppressed during quiet hours 22:00-07:00)
                - needs_response: Requires user input (time-sensitive)
                - urgent: Critical alert (bypasses DND)
                - approval: Yes/no gate (use request_approval instead for gated actions)
            title: Short title (max 100 chars)
            message: Body text (1-3 lines, max 500 chars)
            details_url: URL to open when notification is tapped
            dedupe_key: Unique key to prevent duplicate notifications (auto-generated if not provided)

        Returns:
            JSON string with success status and attention_id
        """
        if not dedupe_key:
            import uuid
            dedupe_key = f"agent_{uuid.uuid4().hex[:8]}"

        result = await self._request("POST", "/actions/notify_attention", {
            "severity": severity,
            "title": title,
            "message": message,
            "details_url": details_url,
            "dedupe_key": dedupe_key,
        })

        return json.dumps(result, indent=2)

    async def request_approval(
        self,
        action_type: str,
        action_payload: Dict[str, Any],
        description: str,
        ttl_seconds: int = 300,
    ) -> str:
        """
        Request user approval for a sensitive action.

        Sends an iOS push notification with APPROVE/DENY buttons.
        After calling this, use check_approval to poll for the decision.

        Args:
            action_type: Type of action (e.g., 'github_issue', 'webhook', 'file_write')
            action_payload: The exact payload that will be executed if approved
            description: Human-readable description of what will happen
            ttl_seconds: How long the approval is valid (default 5 minutes)

        Returns:
            JSON string with approval_id and expiration time
        """
        result = await self._request("POST", "/actions/request_approval", {
            "action_type": action_type,
            "action_payload": action_payload,
            "description": description,
            "ttl_seconds": ttl_seconds,
        })

        return json.dumps(result, indent=2)

    async def check_approval(
        self,
        approval_id: str,
        action_payload: Dict[str, Any],
    ) -> str:
        """
        Check if an approval request has been approved.

        Args:
            approval_id: The approval_id returned from request_approval
            action_payload: The exact same payload that was submitted for approval

        Returns:
            JSON string with:
            - approved: true/false
            - status: 'pending', 'approved', 'denied', 'expired'
            - reason: Explanation if not approved
        """
        result = await self._request("POST", "/actions/check_approval", {
            "approval_id": approval_id,
            "action_payload": action_payload,
        })

        return json.dumps(result, indent=2)

    async def list_pending_approvals(self) -> str:
        """
        List all pending approval requests.

        Returns:
            JSON string with count and list of pending approvals
        """
        result = await self._request("GET", "/actions/pending_approvals")
        return json.dumps(result, indent=2)

    async def check_reliability_status(self) -> str:
        """
        Check current reliability status including quiet hours and rate limits.

        Returns:
            JSON string with:
            - quiet_hours: Whether FYI notifications are currently suppressed
            - rate_limits: Current usage vs limits per severity
            - retry_config: Retry settings
        """
        result = await self._request("GET", "/actions/reliability_status")
        return json.dumps(result, indent=2)

    async def read_file(self, file_path: str) -> str:
        """
        Read contents of an allowlisted file.

        Args:
            file_path: Absolute path to the file (must be in allowlist)

        Returns:
            JSON string with file contents or error
        """
        result = await self._request("POST", "/actions/read_file", {
            "file_path": file_path,
        })

        return json.dumps(result, indent=2)

    async def search_docs(
        self,
        query: str,
        collection: str = "infrastructure_docs",
        limit: int = 5,
    ) -> str:
        """
        Search documents using RAG (semantic search).

        Args:
            query: Natural language search query
            collection: Document collection to search (default: infrastructure_docs)
            limit: Maximum number of results to return

        Returns:
            JSON string with matching document chunks and sources
        """
        result = await self._request("POST", "/actions/search_docs", {
            "query": query,
            "collection": collection,
            "limit": limit,
        })

        return json.dumps(result, indent=2)
